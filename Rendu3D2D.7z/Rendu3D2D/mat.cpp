#include <string.h>
#define _USE_MATH_DEFINES
#include <cmath>
#include "mat.h"

mat4::mat4()
{
	for (int i = 0; i < 16; i++)
	{
		data[i] = 0;
	}
	data[0] = 1;
	data[5] = 1;
	data[10] = 1;
	data[15] = 1;
}

mat4 mat4::identity()
{
	mat4 res;
	res.data[0] = 1;
	res.data[5] = 1;
	res.data[10] = 1;
	res.data[15] = 1;
	return res;
}

mat4 mat4::rotate(float angle)
{
	mat4 res;
	res.data[10] = cos(angle);
	res.data[6] = sin(angle);
	res.data[9] = -sin(angle);
	res.data[5] = cos(angle);
	return res;
}
mat4 mat4::scale(float factor)
{
	mat4 res;
	res.data[0] = factor;
	res.data[5] = factor;
	res.data[10] = factor;
	return res;
}

mat4 mat4::translate(float x, float y, float z)
{
	mat4 res;
	res.data[12] = x;
	res.data[13] = y;
	res.data[14] = z;
	return res;
}

mat4 mat4::ortho(float left, float right, float bottom, float top, float znear, float zfar)
{
	mat4 res;
	res.data[0] = 2/(right-left);
	res.data[5] = 2 / (top - bottom);
	res.data[10] = -2 / (zfar - znear);
	res.data[3] = -((right+left)/(right-left));
	res.data[7] = -((top + bottom) / (top - bottom));
	res.data[11] = -((zfar + znear) / (zfar - znear));
	return res;
}

mat4 mat4::perspec(float fovy, float aspect, float zNear, float zFar)
{
	mat4 res;
	fovy = fovy * (M_PI / 180.0f);
	res.data[0] = (1.f/tan(fovy / 2.0f)) / aspect;
	res.data[5] = 1.f/tan(fovy / 2.0f);
	res.data[10] = -((zFar) / (zFar - zNear));
	res.data[11] = -1.0f;
	res.data[14] = -((zNear*zFar) / (zFar - zNear));
	res.data[15] = 0;
	return res;
}


void mat4::setData(float* data)
{
	memcpy(this->data, data, sizeof(float) * 16);
}
float* mat4::getData()
{
	return this->data;
}
