#pragma once

struct Vertex
{
	float x, y;
	float r, g, b;
	float u, v;
};