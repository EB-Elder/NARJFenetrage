#pragma once

struct mat4
{
	private:
	float data[16];

	public:
	mat4 identity();
	mat4 rotate(float);
	mat4 scale(float);
	mat4 translate(float, float, float);
	void setData(float[]);
	mat4 ortho(float left, float right, float bottom, float top, float znear, float zfar);
	mat4 perspec(float fovy, float aspect, float zNear, float zFar);
	mat4 projection(float, float);
	float* getData();
	

	mat4();
};