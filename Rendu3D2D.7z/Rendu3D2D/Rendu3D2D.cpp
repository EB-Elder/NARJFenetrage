//
//
//

// GLEW_STATIC force le linkage statique
// c-a-d que le code de glew est directement injecte dans l'executable
#define GLEW_STATIC
#include <GL/glew.h>
#include <GLFW/glfw3.h>

// les repertoires d'includes sont:
// ../libs/glfw-3.3/include			fenetrage
// ../libs/glew-2.1.0/include		extensions OpenGL
// ../libs/stb						gestion des images (entre autre)

// les repertoires des libs sont (en 64-bit):
// ../libs/glfw-3.3/lib-vc2015
// ../libs/glew-2.1.0/lib/Release/x64

// Pensez a copier les dll dans le repertoire x64/Debug, cad:
// glfw-3.3/lib-vc2015/glfw3.dll
// glew-2.1.0/bin/Release/x64/glew32.dll		si pas GLEW_STATIC

// _WIN32 indique un programme Windows
// _MSC_VER indique la version du compilateur VC++
#if defined(_WIN32) && defined(_MSC_VER)
#pragma comment(lib, "glfw3dll.lib")
#pragma comment(lib, "glew32s.lib")			// glew32.lib si pas GLEW_STATIC
#pragma comment(lib, "opengl32.lib")
#elif defined(__APPLE__)
#elif defined(__linux__)
#endif

#include <iostream>
#include "tiny_obj_loader.h"
#include "Vertex.h"
#include "Vertex3D.h"
#include "../common/GLShader.h"
// fonctions de chargement d'images (bitmap)
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "mat.h"

GLuint LoadTexture(const char* path)
{
	// 1. chargement de la bitmap
	int w, h, c;
	uint8_t* data = stbi_load(path, &w, &h, &c, STBI_rgb_alpha);
	// 2. creation du texture object OpenGL
	GLuint TextureID = 0;
	glGenTextures(1, &TextureID);
	// 3. chargement et parametrage
	// pour pouvoir travailler sur/avec la texture
	// on doit d'abord la "bind" / attacher sur un identifiant
	// en l'occurence GL_TEXTURE_2D
	glBindTexture(GL_TEXTURE_2D, TextureID);
	// les 6 premiers params definissent le stockage de la texture en VRAM (memoire video)
	// les 3 derniers specifient l'image source
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0,
		GL_RGBA, GL_UNSIGNED_BYTE, data);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
		GL_LINEAR);
	// on remet la valeur par defaut (pas obligatoire mais preferable ici)
	glBindTexture(GL_TEXTURE_2D, 0);
	// 4. liberation de la memoire
	stbi_image_free(data);
	return TextureID;
}

void DestroyTexture(GLuint* textureID)
{
	glDeleteTextures(1, textureID);
	textureID = 0;
}

// variables globales (dans le cadre de cet exemple, evitez les globales si possible)
GLShader g_basicShader;
GLuint g_TextureBatman;
std::vector<Vertex3D> vertices;
std::vector<int> indices;
mat4* matrice = new mat4();

GLuint VBO;
GLuint IBO;

void loadModel()
{
	tinyobj::attrib_t attrib;
	std::vector<tinyobj::shape_t> shapes;

	tinyobj::LoadObj(&attrib, &shapes, NULL, NULL, NULL, "models/Suzanne.obj");
	if (shapes.capacity() != 0)
	{
		for (const auto& shape : shapes) {
			for (const auto& index : shape.mesh.indices) {
				Vertex3D vertex = {};

				vertex.x = attrib.vertices[3 * index.vertex_index + 0];
				vertex.y = attrib.vertices[3 * index.vertex_index + 1];
				vertex.z = attrib.vertices[3 * index.vertex_index + 2];

				vertex.nx = attrib.normals[3 * index.normal_index + 0];
				vertex.ny = attrib.normals[3 * index.normal_index + 1];
				vertex.nz = attrib.normals[3 * index.normal_index + 2];

				vertex.u = attrib.texcoords[2 * index.texcoord_index + 0];
				vertex.v = attrib.texcoords[2 * index.texcoord_index + 1];
				



				vertices.push_back(vertex);
				indices.push_back(indices.size());

			}
		}

		glGenBuffers(1, &VBO);
		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(Vertex3D) * vertices.size(), &vertices[0], GL_STATIC_DRAW);

		glGenBuffers(1, &IBO);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(int) * indices.size(), &indices[0], GL_STATIC_DRAW);
	}
	else
	{
		throw;
	}
}

void Initialize()
{
	
	matrice->identity();
	GLenum error = glewInit();
	if (error != GLEW_OK) {
		std::cout << "erreur d'initialisation de GLEW!"
			<< std::endl;
	}

	std::cout << "Version : " << glGetString(GL_VERSION) << std::endl;
	std::cout << "Vendor : " << glGetString(GL_VENDOR) << std::endl;
	std::cout << "Renderer : " << glGetString(GL_RENDERER) << std::endl;

	g_basicShader.LoadVertexShader("basic.vs.glsl");
	g_basicShader.LoadFragmentShader("basic.fs.glsl");
	g_basicShader.Create();

	g_TextureBatman = LoadTexture("batman_logo.png");

	loadModel();
}

void Shutdown()
{
	DestroyTexture(&g_TextureBatman);

	g_basicShader.Destroy();
	delete matrice;
}



void Display(GLFWwindow* window)
{
	int width, height;
	glfwGetWindowSize(window, &width, &height);

	glClearColor(0.f, 0.f, 0.f, 0.f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);

	
	// Defini le viewport en pleine fenetre
	glViewport(0, 0, width, height);
	
	// notez que l'origine des textures en OpenGL est en bas a gauche
	// tandis que l'origine de la bitmap en haut a gauche
	// il est donc necessaire d'inverser le 'v' (coordonnee up de la texture)
	const Vertex triangles[] = {
		{ -0.5f, -0.5f, /*color*/1.f, 0.f, 0.f, /*uv*/0.f, 1.f },
		{ -0.5f, +0.5f, /*color*/0.f, 1.f, 0.f, /*uv*/0.f, 0.f },
		{ +0.5f, +0.5f, /*color*/0.f, 0.f, 1.f, /*uv*/1.f, 0.f },
		// second triangle
		{ -0.5f, -0.5f, /*color*/1.f, 0.f, 0.f, /*uv*/0.f, 1.f },
		{ +0.5f, +0.5f, /*color*/0.f, 0.f, 1.f, /*uv*/1.f, 0.f },
		{ +0.5f, -0.5f, /*color*/1.f, 1.f, 1.f, /*uv*/1.f, 1.f }
	};

	// on peut avoir plusieurs textures en meme temps
	// mais il necessaire de specifier le "canal" (unite de texture/texture unit)
	// sur lequel on va "bind" la texture
	int textureUnit = 0;
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, g_TextureBatman);

	uint32_t program = g_basicShader.GetProgram();
	glUseProgram(program);

	// Dans le shader, notre texture object est utilisee via un Sampler2D
	// il faut indiquer a OpenGL l'unite de texture correspondante
	// notre variable etant de classe "uniform" on utilise la fonction correspondante
	int texture_location = glGetUniformLocation(program, "u_TextureSampler");
	// on indique au fragment shader qu'il faut "sampler" l'unite de texture 0 (TEXTURE0)
	glUniform1i(texture_location, textureUnit);



	int position_location = glGetAttribLocation(program, "a_position");
	// Specifie la structure des donnees envoyees au GPU
	glVertexAttribPointer(position_location, 3, GL_FLOAT, false, sizeof(Vertex3D), 0);
	// indique que les donnees sont sous forme de tableau
	glEnableVertexAttribArray(position_location);
	
	// 3 floats pour les couleurs
	int color_location = glGetAttribLocation(program, "a_color");
	// Specifie la structure des donnees envoyees au GPU
	glEnableVertexAttribArray(color_location);
	glVertexAttribPointer(color_location, 3, GL_FLOAT, false, sizeof(Vertex3D), 0);
	// indique que les donnees sont sous forme de tableau
	
	// 2 floats pour les coordonnees de texture
	int texcoords_location = glGetAttribLocation(program, "a_texcoords");
	// Specifie la structure des donnees envoyees au GPU
	glEnableVertexAttribArray(texcoords_location);
	glVertexAttribPointer(texcoords_location, 2, GL_FLOAT, false, sizeof(Vertex3D), (GLvoid*) offsetof(Vertex3D, u));
	// indique que les donnees sont sous forme de tableau
	

	
	
	int matriceLocRot = glGetUniformLocation(program, "rotateMat");
	int matriceLocTranslate = glGetUniformLocation(program, "translateMat");
	int matriceLocScale = glGetUniformLocation(program, "scaleMat");
	int matriceOrtho = glGetUniformLocation(program, "orthoMat");
	int matricePerspec = glGetUniformLocation(program, "perspecMat");
	
	//multiplier les matrices directement dans le VS
	mat4 matRot = matrice->rotate(glfwGetTime() * 0.4);
	mat4 matTrans = matrice->translate(glfwGetTime() * 0.0, 0, -5.f);
	mat4 matScale = matrice->scale(1.0f);
	mat4 matOrtho = matrice->ortho(-1, 1, -1, 1, 0, 15);
	mat4 matPerspec = matrice->perspec(45.0f, (float) width / (float) height, 1.0f, 100.0f);

	glUniformMatrix4fv(matriceLocRot, 1, false, matRot.getData());
	glUniformMatrix4fv(matriceLocTranslate, 1, false, matTrans.getData());
	glUniformMatrix4fv(matriceLocScale, 1, false, matScale.getData());
	glUniformMatrix4fv(matriceOrtho, 1, false, matOrtho.getData());
	glUniformMatrix4fv(matricePerspec, 1, false, matPerspec.getData());


	

	// dessine deux triangles
	//glBindVertexArray(VBO);
	//glDrawArrays(GL_TRIANGLES, 0, vertices.size());
	glDrawElements(GL_TRIANGLES, vertices.size(), GL_UNSIGNED_INT, 0);// (void*)indices.size());



	

}

int main(void)
{
	GLFWwindow* window;

	/* Initialize the library */
	if (!glfwInit())
		return -1;

	/* Create a windowed mode window and its OpenGL context */
	window = glfwCreateWindow(640, 480, "Hello World", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	/* Make the window's context current */
	glfwMakeContextCurrent(window);

	// toutes nos initialisations vont ici
	Initialize();

	/* Loop until the user closes the window */
	while (!glfwWindowShouldClose(window))
	{
		/* Render here */
		Display(window);

		/* Swap front and back buffers */
		glfwSwapBuffers(window);

		/* Poll for and process events */
		glfwPollEvents();
	}

	// ne pas oublier de liberer la memoire etc...
	Shutdown();

	glfwTerminate();
	return 0;
}